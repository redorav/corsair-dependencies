#ifndef ASSIMP_REVISION_H_INC
#define ASSIMP_REVISION_H_INC

#define GitVersion 0x1
#define GitBranch "1"

#endif // ASSIMP_REVISION_H_INC
